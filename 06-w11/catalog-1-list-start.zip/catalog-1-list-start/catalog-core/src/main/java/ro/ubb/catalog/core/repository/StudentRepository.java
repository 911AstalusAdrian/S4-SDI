package ro.ubb.catalog.core.repository;

import ro.ubb.catalog.core.model.Student;

public interface StudentRepository extends CatalogRepository<Student, Long> {
}
